<?xml version="1.0" encoding="UTF-8"?>
<tileset name="background" tilewidth="16" tileheight="16" tilecount="240" columns="24">
 <grid orientation="orthogonal" width="32" height="32"/>
 <image source="background.png" width="384" height="160"/>
</tileset>
