import pygame
from settings import game_settings
from world import World
from DQN_fighter import playGame

if __name__ == '__main__':

    playGame()
    pygame.quit()