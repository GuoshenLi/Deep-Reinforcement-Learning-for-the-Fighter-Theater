#!/usr/bin/env python

from __future__ import print_function
import tensorflow as tf
import cv2
import sys
import py_test as game
import random
from collections import deque
import pygame
from settings import game_settings
from world import World
import matplotlib.pyplot as plt
from BrainDQN_Nature import BrainDQN, access_Q_MAX_diagram
import numpy as np
from py_test import access_reward_diagram
import scipy.io as sio

sys.path.append("game/")
# preprocess raw image to 80*80 gray image
def preprocess(observation):
	observation = cv2.cvtColor(cv2.resize(observation, (80, 80)), cv2.COLOR_BGR2GRAY)
	observation = observation / 255.
	return np.reshape(observation,(80,80,1))

def playGame():
	# Step 1: init BrainDQN
	actions = 4
	brain = BrainDQN(actions)
	# Step 2: init Flappy Bird Game
	FighterTheater = game.GameState()
	# Step 3: play game
	# Step 3.1: obtain init state
	action0 = np.array([1,0,0,0])  # do nothing
	observation0, reward0, terminal = FighterTheater.frame_step(action0)
	observation0 = cv2.cvtColor(cv2.resize(observation0, (80, 80)), cv2.COLOR_BGR2GRAY)
	observation0 = observation0 / 255.
	brain.setInitState(observation0)

	# Step 3.2: run the game
	while brain.timeStep <= 2000000:
		action = brain.getAction()
		nextObservation,reward,terminal = FighterTheater.frame_step(action)

		print("TIMESTEP", brain.timeStep, "/ STATE", brain.state, \
			  "/ EPSILON", brain.epsilon,\
			  "/ ACTION", np.argmax([action]), "/ REWARD", reward)
		print("left(green) score", game_settings.left_score, "right(red) score", game_settings.right_score)

		nextObservation = preprocess(nextObservation)
		brain.setPerception(nextObservation,action,reward,terminal)



############################# Draw_Diagram #######################
	reward_history = access_reward_diagram()
	Q_MAX_history = access_Q_MAX_diagram()

	sio.savemat('reward_history.mat', {'reward_history': reward_history})
	sio.savemat('Q_MAX_history.mat', {'Q_MAX_history': Q_MAX_history})

	plt.plot(range(1,len(reward_history)+1), reward_history)
	plt.xlim(1,len(reward_history))
	plt.xlabel('Game Epoch')
	plt.ylabel('Reward')
	plt.show()

	plt.plot(range(1,len(Q_MAX_history)+1), Q_MAX_history)
	plt.xlim(1,len(Q_MAX_history))
	plt.xlabel('Iteration')
	plt.ylabel('Maximum Q Value')
	plt.show()

