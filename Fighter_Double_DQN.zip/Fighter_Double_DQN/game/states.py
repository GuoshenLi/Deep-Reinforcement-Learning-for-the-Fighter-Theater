from random import randint
import os
from gameobjects.vector2 import Vector2
import pygame
from settings import game_settings


class State(object): #each of the four states need to contain a name and four function
    def __init__(self, name):
        self.name = name

    def do_actions(self):
        pass

    def check_conditions(self):
        pass

    def entry_actions(self):
        pass

    def exit_actions(self):
        pass

    def __unicode__(self):
        return self.name

    __str__ = __unicode__

HERO_STATES = (
    'exploring',
    'seeking',
    'fighting',
    'delivering'
)

def load_alpha_image_bg(resource_img):
    path = os.path.join(
        game_settings.BASE_DIR,
        'img/{}'.format(resource_img),
    )

    return pygame.image.load(path)

energy_background_img = load_alpha_image_bg('energy_background.png')


class StateMachine(object):  #the object here is self.brain
    def __init__(self):
        self.states = {}  #is equal to self.brain.state{state's name: object state}
        self.active_state = None  # active_state is current state, which is an State object

    def add_state(self, state):
        self.states[state.name] = state

    def red_think(self):  #the transform of state
        if self.active_state is None:
            return

        self.active_state.do_actions() #do_actions in current state
        new_state_name = self.active_state.check_conditions() #check if another state's condition is qualified

        if new_state_name is not None: #if another state is ready for entry, set_state
            self.set_state(new_state_name)

    def green_think(self, input_action):  #the transform of state
        if self.active_state is None:   #default active state is exploring
            return



        if input_action[0] == 1:
            new_state_name = HERO_STATES[0]

        if input_action[1] == 1:
            new_state_name = HERO_STATES[1]

        if input_action[2] == 1:
            new_state_name = HERO_STATES[2]

        if input_action[3] == 1:
            new_state_name = HERO_STATES[3]


        self.active_state = self.states[new_state_name]

        self.active_state.do_actions() #do_actions in current state
        #new_state_name = self.active_state.check_conditions() #check if another state's condition is qualified



    def set_state(self, new_state_name):
        if self.active_state is not None:
            self.active_state.exit_actions()  #active_state is none can also trigger set_state

        self.active_state = self.states[new_state_name]
        self.active_state.entry_actions()





class HeroStateExploring_red(State):
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[0])  #exploring_state.name = HERO_STATES[0]
        self.hero = hero

    def random_destination(self): # go to the center of the map, create more chances to fight
        w, h = game_settings.SCREEN_SIZE
        #self.hero.destination = Vector2(randint(60, w - 60), randint(60, h - 60))
        self.hero.destination = Vector2(randint(w/2 - 200, w/2 + 200),  randint(150, h - 150))

    def do_actions(self):
        if randint(1, 10) == 1:
            self.random_destination()


    def check_conditions(self):
        location = self.hero.location
        world = self.hero.world

        enemy_type = self.hero.get_enemy_type()
        enemy = world.get_close_entity(
            enemy_type,
            location,
            game_settings.DEFAULT_SEARCH_RANGE,
        )

        # exploring --> fighting if there is an enemy that is close to him(Change the state)
        if enemy is not None and location.get_distance_to(enemy.location) < 200.:
            self.hero.enemy_id = enemy.id
            return HERO_STATES[2]

        energy_store = world.get_close_energy(self.hero.location)

        # exploring --> seeking
        if energy_store is not None:
            self.hero.energy_id = energy_store.id
            return HERO_STATES[1]

        return None

    def entry_actions(self):
        #self.hero.speed = 120. + randint(-30, 30)
        self.hero.speed = 120.
        self.random_destination()


class HeroStateExploring_green(State): #ramdomly go to a place
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[0])  #exploring_state.name = HERO_STATES[0]
        self.hero = hero

    def random_destination(self): # go to the center of the map, create more chances to fight
        w, h = game_settings.SCREEN_SIZE
        #self.hero.destination = Vector2(randint(60, w - 60), randint(60, h - 60))
        self.hero.destination = Vector2(randint(w/2 - 200, w/2 + 200),  randint(150, h - 150))

    def do_actions(self):
        if randint(1, 10) == 1:
            self.random_destination()


    def entry_actions(self):
        #self.hero.speed = 120. + randint(-30, 30)
        self.hero.speed = 120.
        self.random_destination() ####  #kfdfd



class HeroStateSeeking_red(State):
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[1]) #seeking_state.name = HERO_STATES[1]
        self.hero = hero
        self.energy_id = None

    def check_conditions(self):
        world = self.hero.world
        location = self.hero.location
        energy_store = world.get_energy_store(self.hero.energy_id)

        if energy_store is None:
            return HERO_STATES[0]

        if location.get_distance_to(energy_store.location) < 5.0: #carry energy and add blood
            self.hero.carry(energy_store.image)
            self.hero.world.remove_energy_store(energy_store)

            for entity in world.entities.values():  #if one hero get stone, then all the hero of his side can also add blood
                if entity.hero_type == self.hero.hero_type:
                    entity.health += 3
                    if entity.health > game_settings.MAX_HEALTH:
                        entity.health = game_settings.MAX_HEALTH
            print(entity.hero_type,"hero carry energy stone and add blood to his hero")
            return HERO_STATES[3]

        self.hero.destination = energy_store.location
        return None

    def entry_actions(self):
        energy_store = self.hero.world.get(self.hero.energy_id)
        if energy_store is not None:
            self.hero.destination = energy_store.location
            #self.hero.speed = 160. + randint(-20, 20)
            self.hero.speed = 120


class HeroStateSeeking_green(State):
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[1]) #seeking_state.name = HERO_STATES[1]
        self.hero = hero
        #self.energy_id = None

    def do_actions(self):
        world = self.hero.world
        location = self.hero.location

        energy_store = world.get_close_energy(self.hero.location)

        if energy_store is None:   #random destination
            w, h = game_settings.SCREEN_SIZE
            if randint(1, 5) == 1:
                self.hero.destination = Vector2(randint(w / 2 - 200, w / 2 + 200), randint(150, h - 150))

        #energy_store = world.get_energy_store(self.hero.energy_id)

        else:
            if location.get_distance_to(energy_store.location) < 5.0: #carry energy and add blood
                self.hero.carry(energy_store.image)
                self.hero.world.remove_energy_store(energy_store)

                for entity in world.entities.values():  #if one hero get stone, then all the hero of his side can also add blood
                    if entity.hero_type == self.hero.hero_type:
                        entity.health += 3
                        if entity.health > game_settings.MAX_HEALTH:
                            entity.health = game_settings.MAX_HEALTH
                print(entity.hero_type,"hero carry energy stone and add blood to his hero")


            else:
                self.hero.destination = energy_store.location

        return None

    def entry_actions(self):
        energy_store = self.hero.world.get(self.hero.energy_id)
        if energy_store is not None:
            self.hero.destination = energy_store.location
            #self.hero.speed = 160. + randint(-20, 20)
            self.hero.speed = 120



class HeroStateDelivering_red(State): #exploring_state.name = HERO_STATES[3]
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[3])
        self.hero = hero

    def check_conditions(self):
        location = self.hero.location
        world = self.hero.world
        home_location = Vector2(*self.hero.get_home_location())
        distance_to_home = home_location.get_distance_to(location)

        if distance_to_home < game_settings.DROP_RANGE or not self.hero.in_center():
            if randint(1, 10) == 1:
                self.hero.drop(world.background_layer, energy_background_img)
                self.hero.add_energy_score()
                return HERO_STATES[0]

        return None

    def entry_actions(self):
        home_location = Vector2(*self.hero.get_home_location())
        #self.hero.speed = 100.0
        self.hero.speed = 120.0
        random_offset = Vector2(randint(-20, 20), randint(-20, 20))
        self.hero.destination = home_location + random_offset


class HeroStateDelivering_green(State):
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[3])
        self.hero = hero

    def do_actions(self):

        location = self.hero.location
        world = self.hero.world
        home_location = Vector2(*self.hero.get_home_location())
        distance_to_home = home_location.get_distance_to(location)

        if self.hero.carry_energy_store is not None:
            if distance_to_home < game_settings.DROP_RANGE or not self.hero.in_center():
                    self.hero.drop(world.background_layer, energy_background_img)
                    self.hero.add_energy_score()
                    world.reward += 1

        random_offset = Vector2(randint(-20, 20), randint(-20, 20))
        self.hero.destination = home_location + random_offset

        return None


# class HeroStateFighting(State):  #hunting_state.name is HERO_STATES[2]
#     def __init__(self, hero):
#         State.__init__(self, HERO_STATES[2])
#         self.hero = hero
#         self.got_kill = False
#
#     def do_actions(self):
#         world = self.hero.world
#         enemy = world.get(self.hero.enemy_id)
#         if enemy is None:
#             return
#
#         self.hero.destination = enemy.location
#         offset = self.hero.location.get_distance_to(enemy.location) < 15.
#         random_seed = randint(1, 5) == 1
#
#         if offset and random_seed:
#             enemy.bitten()
#             if enemy.health <= 0:
#                 enemy.dead()
#                 world.remove_entity(enemy)
#                 self.got_kill = True
#
#     def check_conditions(self):
#         if self.got_kill:
#             return HERO_STATES[3]
#
#         enemy = self.hero.world.get(self.hero.enemy_id)
#
#         if enemy is None:
#             return HERO_STATES[0]
#
#         if self.hero.health < 2 / 3 * game_settings.MAX_HEALTH:
#             self.hero.destination = self.hero.get_home_location()
#             return HERO_STATES[0]
#
#         return None
#
#     def entry_actions(self):
#         self.speed = 160. + randint(0, 50)
#
#     def exit_actions(self):
#         self.got_kill = False


class HeroStateFighting_green(State):  #hunting_state.name is HERO_STATES[2] have the ability to go home
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[2])
        self.hero = hero
        self.got_kill = False



    def do_actions(self):
        world = self.hero.world
        location = self.hero.location
        self.speed = 120.
        enemy_type = self.hero.get_enemy_type()
        enemy = world.get_close_entity(
            enemy_type,
            location,
        )

        if enemy is None:

            if randint(1, 5) ==1:
                w, h = game_settings.SCREEN_SIZE
            # self.hero.destination = Vector2(randint(60, w - 60), randint(60, h - 60))
                self.hero.destination = Vector2(randint(w / 2 - 200, w / 2 + 200), randint(150, h - 150))


        if enemy is not None:
            self.hero.enemy_id = enemy.id
            enemy = world.get(self.hero.enemy_id)

            self.hero.destination = enemy.location
            offset = self.hero.location.get_distance_to(enemy.location) < 15.


            if offset:

                if game_settings.left_score >= 2 and self.hero.health < 5 and \
                        randint(1,2) == 1:
                    enemy.super_kill()
                    world.reward += 1
                    print("green hero has use super kill")
                else:
                    enemy.bitten()
                    world.reward += 1

                if enemy.health <= 0:
                    #enemy.dead()    #do not show grave
                    world.remove_entity(enemy)
                    self.got_kill = True
                    world.reward += 10

                    print("already killed an enemy")

                # if randint(1,2) == 1:
                #     w, h = game_settings.SCREEN_SIZE
                #     #self.hero.destination = Vector2(randint(60, w - 60), randint(60, h - 60))
                #     self.hero.destination = Vector2(randint(w/2 - 300, w/2 + 300),  randint(100, h - 100))



        #if self.hero.health < 2 / 3 * game_settings.MAX_HEALTH:
            #self.hero.destination = self.hero.get_home_location()
            #return HERO_STATES[0]

        return None



class HeroStateFighting_red(State):  #hunting_state.name is HERO_STATES[2] without the ability to go home
    def __init__(self, hero):
        State.__init__(self, HERO_STATES[2])
        self.hero = hero
        self.got_kill = False

    def do_actions(self):
        world = self.hero.world
        enemy = world.get(self.hero.enemy_id)
        if enemy is None:
            return

        self.hero.destination = enemy.location
        offset = self.hero.location.get_distance_to(enemy.location) < 15.
        random_seed = randint(1, 4) == 1

        if offset and random_seed:

            enemy.bitten()

            if self.hero.health < 10 and game_settings.right_score >= 3 and randint(1,3) !=1:
                self.hero.red_hero_fighting_add_blood()
                print("red hero add blood in fighting state")

            if enemy.health <= 0:
                #enemy.dead() #do not show grave
                world.remove_entity(enemy)
                self.got_kill = True

    def check_conditions(self):
        if self.got_kill:
            return HERO_STATES[0]

        enemy = self.hero.world.get(self.hero.enemy_id)

        if enemy is None:
            return HERO_STATES[0]

        return None

    def entry_actions(self):
        #self.speed = 160. + randint(0, 50)
        self.speed = 120
    def exit_actions(self):
        self.got_kill = False