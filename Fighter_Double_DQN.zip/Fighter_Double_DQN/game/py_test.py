
import sys
from settings import game_settings
from world import World
import pygame


sys.path.append("game/")

game_exit = False
game_over = True
count_test = 0
pygame.init()
pygame.display.set_caption('Python Game')
game_screen = pygame.display.set_mode(
    (game_settings.SCREEN_WIDTH, game_settings.SCREEN_HEIGHT),
    pygame.DOUBLEBUF | pygame.HWSURFACE,
    32,
)

reward_history = []

class GameState:

    def __init__(self):


        self.game_world = World(game_screen) #game_world is an object  #initialize
        self.clock = pygame.time.Clock()

        game_settings.left_score = 100
        game_settings.right_score = 100
        self.gameframe_per_epoch = 0
        self.game_world.render(game_screen)


    def frame_step(self, input_action):
        pygame.event.pump()

        terminal = False

        time_passed = self.clock.tick(300)
        self.game_world.random_emit()

        self.game_world.process(time_passed, input_action)  #input_action is an one by four array
        self.gameframe_per_epoch += 1
        #check if terminal

        green_number = self.game_world.hero_nums['green']
        red_number = self.game_world.hero_nums['red']

        if green_number == 0:
            if game_settings.left_score < 10:
                terminal = True
                print("gameover------------------------------\n" * 5)
                self.game_world.reward -= 500
                self.game_world.reward /= float(self.gameframe_per_epoch)
                reward_history.append(self.game_world.reward)
                self.__init__()

        if red_number == 0:
            if game_settings.right_score < 10:
                terminal = True
                print("gameover------------------------------\n" * 5)
                self.game_world.reward += 500
                self.game_world.reward /= float(self.gameframe_per_epoch)
                reward_history.append(self.game_world.reward)
                self.__init__()

        self.game_world.render(game_screen)

        image_data = pygame.surfarray.array3d(pygame.display.get_surface())

        pygame.display.update()



        return image_data, self.game_world.reward, terminal


def access_reward_diagram():

    return reward_history