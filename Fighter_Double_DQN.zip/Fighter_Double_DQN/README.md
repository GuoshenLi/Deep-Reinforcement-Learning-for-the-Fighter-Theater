# FighterTheater

![show](art/show.gif)

## How to use?

start virtural env

``` shell
cd gameobjects-0.0.3
python ./setup.py install

pip install -r requirements.txt
```

run:

``` shell
python game
```
